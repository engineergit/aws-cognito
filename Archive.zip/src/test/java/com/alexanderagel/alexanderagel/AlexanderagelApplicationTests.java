package com.alexanderagel.alexanderagel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlexanderagelApplicationTests {

	@Test
	void contextLoads() {
	}

}
