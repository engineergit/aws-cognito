package com.alexanderagel.alexanderagel;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("message", "You hava successfully logged in!");
        return "Home";
    }

    @GetMapping("/test")
    public String adminGreet(Model model) {
        String message = "Welcome to the test page! This is an amazing website!";
        model.addAttribute("message", message);

        return "test";
    }
}
